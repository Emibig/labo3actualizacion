package proyecto.internaciondomiciliaria.entities;

import java.util.Date;

public class Visita {
    private int id_visita;
    private int id_paciente;
    private int id_chofer;
    private String zona;
    private Date fecha;
    private String hora_inicio;
    private String hora_fin;
    private String coordinado;
    private String concretado;
    private int chofer;

    public Visita() {
    }

    /* constructor sin id */
    public Visita(String zona, Date fecha, String hora_inicio, String hora_fin, String coordinado, String concretado,
            int chofer) {
        this.zona = zona;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.coordinado = coordinado;
        this.concretado = concretado;
        this.chofer = chofer;
    }
    
    public Visita(int id_visita, int id_paciente, int id_chofer, String zona, Date fecha, String hora_inicio,
            String hora_fin, String coordinado, String concretado, int chofer) {
        this.id_visita = id_visita;
        this.id_paciente = id_paciente;
        this.id_chofer = id_chofer;
        this.zona = zona;
        this.fecha = fecha;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
        this.coordinado = coordinado;
        this.concretado = concretado;
        this.chofer = chofer;
    }

    @Override
    public String toString() {
        return "Visita [id_visita=" + id_visita + ", id_paciente=" + id_paciente + ", id_chofer=" + id_chofer
                + ", zona=" + zona + ", fecha=" + fecha + ", hora_inicio=" + hora_inicio + ", hora_fin=" + hora_fin
                + ", coordinado=" + coordinado + ", concretado=" + concretado + ", chofer=" + chofer + "]";
    }

    public int getId_visita() {
        return id_visita;
    }

    public void setId_visita(int id_visita) {
        this.id_visita = id_visita;
    }

    public int getId_paciente() {
        return id_paciente;
    }

    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    public int getId_chofer() {
        return id_chofer;
    }

    public void setId_chofer(int id_chofer) {
        this.id_chofer = id_chofer;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getHora_inicio() {
        return hora_inicio;
    }

    public void setHora_inicio(String hora_inicio) {
        this.hora_inicio = hora_inicio;
    }

    public String getHora_fin() {
        return hora_fin;
    }

    public void setHora_fin(String hora_fin) {
        this.hora_fin = hora_fin;
    }

    public String getCoordinado() {
        return coordinado;
    }

    public void setCoordinado(String coordinado) {
        this.coordinado = coordinado;
    }

    public String getConcretado() {
        return concretado;
    }

    public void setConcretado(String concretado) {
        this.concretado = concretado;
    }

    public int getChofer() {
        return chofer;
    }

    public void setChofer(int chofer) {
        this.chofer = chofer;
    }

}
