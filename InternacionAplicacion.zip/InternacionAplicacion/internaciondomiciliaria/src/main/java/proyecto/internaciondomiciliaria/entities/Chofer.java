package proyecto.internaciondomiciliaria.entities;

public class Chofer {
    private int id_chofer;
    private String vehiculo;
    private String nombre_chofer;
    private String zona;

    public Chofer() {
    }

    public Chofer(String vehiculo, String nombre_chofer, String zona) {
        this.vehiculo = vehiculo;
        this.nombre_chofer = nombre_chofer;
        this.zona = zona;
    }

    public Chofer(int id_chofer, String vehiculo, String nombre_chofer, String zona) {
        this.id_chofer = id_chofer;
        this.vehiculo = vehiculo;
        this.nombre_chofer = nombre_chofer;
        this.zona = zona;
    }

    @Override
    public String toString() {
        return "Chofer [id_chofer=" + id_chofer + ", vehiculo=" + vehiculo + ", nombre_chofer=" + nombre_chofer
                + ", zona=" + zona + "]";
    }

    public int getId_chofer() {
        return id_chofer;
    }

    public void setId_chofer(int id_chofer) {
        this.id_chofer = id_chofer;
    }

    public String getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(String vehiculo) {
        this.vehiculo = vehiculo;
    }

    public String getNombre_chofer() {
        return nombre_chofer;
    }

    public void setNombre_chofer(String nombre_chofer) {
        this.nombre_chofer = nombre_chofer;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

}
